Name:
  Uninstall Office 2016.

Description:
  This tool lets you uninstall or remove so manually Office 2016.

Note:
  This tool cannot do it's job without administrative permissions.

URL:
  https://gallery.technet.microsoft.com/Uninstall-Office-2016-6f3fa204 (English).
  https://gallery.technet.microsoft.com/Desinstalar-o-Eliminar-df602f98 (Spanish).

The tool command consists of the following files:
  UninstallO16.cmd
  License.pdf

Author:
  Manuel Gil.

Version:
  2.0

Credits:
  Thank you for downloading this file.
  This tool was designed for your use, Enjoy!!.
