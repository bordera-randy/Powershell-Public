﻿# Please Configure the following variables....
clear-host
#Get Users From AD who are enabled
Import-Module ActiveDirectory
$users = get-aduser -filter * -properties * |where {$_.Enabled -eq "True"} | where { $_.PasswordNeverExpires -eq $false }
$Dates = get-date -format M
$LogLocation = ("C:\Scripts\" + "PWLog" + $Dates + ".txt")
	
foreach ($user in $users)
{
    $Name = (Get-ADUser $user | foreach { $_.Name})
    $emailaddress = $user.emailaddress
    if (($emailaddress) -ne $null)
    {
        Write-Host $Name","$emailaddress","$passwordsetdate","$maxpasswordage","$expireson","$daystoexpire
    }
    else
    {
        write-output $name" does not have an email address" | Out-File -FilePath $LogLocation -Append
    }
}