** Reset Windows Update Tool (http://wureset.com) **

Description:
  This tool reset the Windows Update Components.

Requirements
  Microsoft Windows XP or later

Donate:
  If you want to help me to continue this project, you might donate via PayPal - https://paypal.me/ManuelFGil

The tool command consists of the following files:
  ResetWUEng.cmd

Version:
  10.5.3.7

Support:
  Issues: https://github.com/ManuelGil/Reset-Windows-Update-Tool/issues
  Wiki: https://github.com/ManuelGil/Reset-Windows-Update-Tool/wiki
  Docs: http://docs.wureset.com

Tell me your opinion:
  Twitter: @wureset

Author:
  Manuel Gil - https://github.com/ManuelGil 

License:
  Reset Windows Update Tool (Script) is licensed under the MIT License - see (https://opensource.org/licenses/MIT)
  for details.

Note:
  Thank you for downloading this file.
  This tool was designed for your use, Enjoy!!.
