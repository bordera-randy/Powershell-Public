﻿clear-host

#Get Users From AD who are enabled
Import-Module ActiveDirectory
$users = get-aduser -filter * -properties * |where {$_.Enabled -eq "True"} | where { $_.PasswordNeverExpires -eq $false } | where { $_.passwordexpired -eq $false } | where { $_.emailaddress -ne $null }
$Dates = get-date -format M
#$LogLocation = ("C:\Scripts\" + "PWLog" + $Dates + ".txt")
	
foreach ($user in $users)
{ 
  $Name = (Get-ADUser $user | foreach { $_.Name})
  #$emailaddress = $user.emailaddress
  $passwordSetDate = (get-aduser $user -properties * | foreach { $_.PasswordLastSet })
  $PasswordPol = (Get-AduserResultantPasswordPolicy $user)
    # Check for Fine Grained Password
  	  if (($PasswordPol) -ne $null)
	  {
		$maxPasswordAge = ($PasswordPol).MaxPasswordAge
	  }
	  else
	  {
		$maxPasswordAge = (Get-ADDefaultDomainPasswordPolicy).MaxPasswordAge
	  }
	  
	  
	  $expireson = $passwordsetdate + $maxPasswordAge
	  $today = (get-date)
	  $daystoexpire = (New-TimeSpan -Start $today -End $Expireson).Days

    Write-Host "$Name, "$user.emailaddress", $passwordsetdate, $maxpasswordage, $expireson, $daystoexpire"
		

}